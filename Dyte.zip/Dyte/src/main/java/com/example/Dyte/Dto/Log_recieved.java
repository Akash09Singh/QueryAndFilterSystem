package com.example.Dyte.Dto;

import com.example.Dyte.Entity.Log;
import com.fasterxml.jackson.annotation.JsonProperty;

public class Log_recieved {
    private String _id; // MongoDB's default primary key field
    private String level;
    private String message;
    private String resourceId;
    private String timestamp;
    private String traceId;
    private String spanId;
    private String commit;
    private Log.Metadata metadata;

    // Constructors, getters, setters
    public Log_recieved() {
        // Default constructor
    }

    public Log_recieved(String level, String message, String resourceId, String timestamp, String traceId, String spanId, String commit, Log.Metadata metadata) {
        this.level = level;
        this.message = message;
        this.resourceId = resourceId;
        this.timestamp = timestamp;
        this.traceId = traceId;
        this.spanId = spanId;
        this.commit = commit;
        this.metadata = metadata;
    }

    public String get_id() {
        return _id;
    }

    public void set_id(String _id) {
        this._id = _id;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getResourceId() {
        return resourceId;
    }

    public void setResourceId(String resourceId) {
        this.resourceId = resourceId;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    public String getTraceId() {
        return traceId;
    }

    public void setTraceId(String traceId) {
        this.traceId = traceId;
    }

    public String getSpanId() {
        return spanId;
    }

    public void setSpanId(String spanId) {
        this.spanId = spanId;
    }

    public String getCommit() {
        return commit;
    }

    public void setCommit(String commit) {
        this.commit = commit;
    }

    public Log.Metadata getMetadata() {
        return metadata;
    }

    public void setMetadata(Log.Metadata metadata) {
        this.metadata = metadata;
    }
    // Omitted for brevity

    // Inner class for the metadata field
    public static class Metadata {
        private String parentResourceId;

        // getters, setters, constructors for Metadata class
        public Metadata() {
            // Default constructor
        }

        public Metadata(@JsonProperty("parentResourceId") String parentResourceId) {
            this.parentResourceId = parentResourceId;
        }

        public String getParentResourceId() {
            return parentResourceId;
        }

        public void setParentResourceId(String parentResourceId) {
            this.parentResourceId = parentResourceId;
        }
        // Omitted for brevity
    }
}

