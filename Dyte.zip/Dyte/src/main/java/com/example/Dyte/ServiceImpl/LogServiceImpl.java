package com.example.Dyte.ServiceImpl;

import com.example.Dyte.Dto.Filter;
import com.example.Dyte.Entity.Log;
import com.example.Dyte.Repository.LogRepository;
import com.example.Dyte.Service.LogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.support.PageableExecutionUtils;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;


import org.springframework.data.domain.Pageable;
import java.util.List;

@Service
public class LogServiceImpl implements LogService {
    @Autowired
    private LogRepository logRepository;

    @Autowired
    private MongoTemplate mongoTemplate;
    @Override
    public void saveLog(Log log) {
        logRepository.save(log);
    }

    @Override
    public List<Log> findAllLog(Pageable pageable) {
        return logRepository.findAll(pageable).getContent();
    }

    @Override
    public List<Log> filterLogs(String level, String fromDate, String toDate, String message, String resourceId, String commit, String traceId, String spanId, String parentResourceId, Pageable pageable) {

        // Create a query object to filter logs based on provided parameters
        Query query = new Query();



        if (level != null && !level.isEmpty()) {
            query.addCriteria(Criteria.where("level").is(level));
        }

        if (fromDate != null && !fromDate.isEmpty() && toDate != null && !toDate.isEmpty()) {
            fromDate = fromDate.substring(0, fromDate.length() - 1);
            toDate = toDate.substring(0, toDate.length() - 1);
            LocalDateTime from = LocalDateTime.parse(fromDate, DateTimeFormatter.ISO_LOCAL_DATE_TIME);

            // Convert LocalDateTime to Unix timestamp in seconds
            long from_unix = from.atZone(ZoneOffset.UTC).toInstant().toEpochMilli();
            LocalDateTime to = LocalDateTime.parse(toDate, DateTimeFormatter.ISO_LOCAL_DATE_TIME);

            // Convert LocalDateTime to Unix timestamp in seconds
            long to_unix = to.atZone(ZoneOffset.UTC).toInstant().toEpochMilli();
            System.out.println(fromDate);
            System.out.println(toDate);
            System.out.println(from_unix);
            System.out.println(to_unix);
            query.addCriteria(Criteria.where("timestamp")
                    .gte(from_unix) // Logs with timestamps greater than or equal to fromDate
                    .lte(to_unix)); // Logs with timestamps less than or equal to toDate
        }
        if (message != null && !message.isEmpty()) {
            query.addCriteria(Criteria.where("message").is(message));
        }

        if (resourceId != null && !resourceId.isEmpty()) {
            query.addCriteria(Criteria.where("resourceId").is(resourceId));
        }

        if (commit != null && !commit.isEmpty()) {
            query.addCriteria(Criteria.where("commit").is(commit));
        }

        if (traceId != null && !traceId.isEmpty()) {
            query.addCriteria(Criteria.where("traceId").is(traceId));
        }

        if (spanId != null && !spanId.isEmpty()) {
            query.addCriteria(Criteria.where("spanId").is(spanId));
        }

        if (parentResourceId != null && !parentResourceId.isEmpty()) {
            query.addCriteria(Criteria.where("parentResourceId").is(parentResourceId));
        }

        // Execute the query and return the filtered logs


        return mongoTemplate.find(query.with(pageable), Log.class);
    }

    @Override
    public List<Log> searchLogs(String query, Pageable pageable) {
        Criteria criteria = new Criteria();
        criteria.orOperator(
                Criteria.where("level").regex(query, "i"),
                Criteria.where("message").regex(query, "i"),
                Criteria.where("timestamp").regex(query, "i"),
                Criteria.where("traceId").regex(query, "i"),
                Criteria.where("spanId").regex(query, "i"),
                Criteria.where("commit").regex(query, "i"),
                Criteria.where("resourceId").regex(query, "i")
        );

        Query searchQuery = new Query(criteria);
        return  mongoTemplate.find(searchQuery.with(pageable), Log.class);

    }
}
