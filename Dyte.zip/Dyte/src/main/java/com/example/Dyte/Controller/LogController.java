package com.example.Dyte.Controller;

import com.example.Dyte.Dto.Log_recieved;
import com.example.Dyte.Entity.Log;
import com.example.Dyte.Service.LogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.data.domain.Pageable;

import java.util.ArrayList;
import java.util.List;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;

@RestController
@RequestMapping("/dyte")
public class LogController {
    private final LogService logService;

    @Autowired
    public LogController(LogService logService) {
        this.logService = logService;
    }

    @PostMapping("/logs")
    public ResponseEntity<String> saveLog(@RequestBody Log_recieved log_r) {
        Log log = new Log();
        log.set_id(log_r.get_id());
        log.setCommit(log_r.getCommit());
        log.setLevel(log_r.getLevel());
        log.setMessage(log_r.getMessage());
        log.setMetadata(log_r.getMetadata());
        log.setResourceId(log_r.getResourceId());
        log.setSpanId(log_r.getSpanId());
        log.setTraceId(log_r.getTraceId());
        String timestamp = log_r.getTimestamp();
        LocalDateTime dateTime = LocalDateTime.parse(timestamp, DateTimeFormatter.ISO_LOCAL_DATE_TIME);

        // Convert LocalDateTime to Unix timestamp in seconds
        long unixTimestamp = dateTime.toInstant(ZoneOffset.UTC).toEpochMilli();
        log.setTimestamp(unixTimestamp);

        logService.saveLog(log);
        return ResponseEntity.ok("Log saved successfully");
    }
    @GetMapping("/logs")
    public ResponseEntity<List<Log_recieved>> getLogs(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "5") int size
    ){
        Pageable pageable = PageRequest.of(page, size);
        List<Log> logs_t = logService.findAllLog(pageable);
        System.out.println(logs_t.size());
        System.out.println(page);
        System.out.println(size);
        List<Log_recieved> logs = this.convertLogListToLogReceivedList(logs_t);
        return ResponseEntity.ok(logs);
    }
    @GetMapping("/logs/filter")
    public ResponseEntity<List<Log_recieved>> getFilterLogs(
            @RequestParam(name = "level", required = false) String level,
            @RequestParam(name = "fromDate", required = false) String fromDate,
            @RequestParam(name = "toDate", required = false) String toDate,
            @RequestParam(name = "message", required = false) String message,
            @RequestParam(name = "resource-id", required = false) String resourceId,
            @RequestParam(name = "commit", required = false) String commit,
            @RequestParam(name = "trace-id", required = false) String traceId,
            @RequestParam(name = "span-id", required = false) String spanId,
            @RequestParam(name = "parent-resource-id", required = false) String parentResourceId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "5") int size
    ){
        Pageable pageable = PageRequest.of(page, size);
        List<Log> filteredLogs = logService.filterLogs(level, fromDate, toDate, message, resourceId, commit, traceId, spanId, parentResourceId, pageable);
        System.out.println(filteredLogs.size());

        List<Log_recieved> logs = this.convertLogListToLogReceivedList(filteredLogs);
        return ResponseEntity.ok(logs);
    }
    @GetMapping("/logs/search")
    public ResponseEntity<List<Log_recieved>> searchLogs(
            @RequestParam String query,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "5") int size
    ) {
        Pageable pageable = PageRequest.of(page, size);
        List<Log> logs_t = logService.searchLogs(query, pageable);
        List<Log_recieved> logs = this.convertLogListToLogReceivedList(logs_t);
        return ResponseEntity.ok(logs);
    }

    public List<Log_recieved> convertLogListToLogReceivedList(List<Log> logList) {
        List<Log_recieved> logReceivedList = new ArrayList<>();

        for (Log log : logList) {
            Log_recieved logReceived = new Log_recieved();
            logReceived.set_id(log.get_id());
            logReceived.setLevel(log.getLevel());
            logReceived.setMessage(log.getMessage());
            logReceived.setResourceId(log.getResourceId());
            logReceived.setTimestamp(convertUnixTimestampToString(log.getTimestamp()));
            logReceived.setTraceId(log.getTraceId());
            logReceived.setSpanId(log.getSpanId());
            logReceived.setCommit(log.getCommit());
            logReceived.setMetadata(log.getMetadata());

            logReceivedList.add(logReceived);
        }

        return logReceivedList;
    }
    private String convertUnixTimestampToString(Long unixTimestamp) {
        // Convert Unix timestamp in seconds to the desired string format
        Instant instant = Instant.ofEpochSecond(unixTimestamp);
        LocalDateTime dateTime = LocalDateTime.ofInstant(Instant.ofEpochMilli(unixTimestamp), ZoneOffset.UTC);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSSSS");
        return dateTime.format(formatter);
    }
    public List<Log> convertLogReceivedListToLogList(List<Log_recieved> logReceivedList) {
        List<Log> logList = new ArrayList<>();

        for (Log_recieved logReceived : logReceivedList) {
            Log log = new Log();
            log.set_id(logReceived.get_id());
            log.setLevel(logReceived.getLevel());
            log.setMessage(logReceived.getMessage());
            log.setResourceId(logReceived.getResourceId());
            log.setTimestamp(convertStringToUnixTimestamp(logReceived.getTimestamp()));
            log.setTraceId(logReceived.getTraceId());
            log.setSpanId(logReceived.getSpanId());
            log.setCommit(logReceived.getCommit());

            Log.Metadata metadata = new Log.Metadata();
            metadata.setParentResourceId(logReceived.getMetadata().getParentResourceId());
            log.setMetadata(metadata);

            logList.add(log);
        }

        return logList;
    }
    private Long convertStringToUnixTimestamp(String timestamp) {
        // Convert the timestamp string to Unix timestamp in seconds
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSSSS");
        LocalDateTime dateTime = LocalDateTime.parse(timestamp, formatter);
        return dateTime.toEpochSecond(ZoneOffset.UTC);
    }

}
